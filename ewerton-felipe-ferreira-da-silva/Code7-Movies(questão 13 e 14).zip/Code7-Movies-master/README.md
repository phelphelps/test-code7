# Code7 Movies

Listagem de filmes, feito em Angular 12.

### Instalação e execução

Instale as dependências, através do seu Git bash/Powershell/CMD/etc.
```bash
npm install
```
... e inicie a aplicação :)
```bash
npm start
```
