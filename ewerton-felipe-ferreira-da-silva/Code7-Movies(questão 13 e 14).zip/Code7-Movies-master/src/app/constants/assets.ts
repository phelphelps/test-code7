export const userAvatar = 'assets/images/user_avatar.jpg';

export const loadingSVG = 'assets/images/loader.svg';
