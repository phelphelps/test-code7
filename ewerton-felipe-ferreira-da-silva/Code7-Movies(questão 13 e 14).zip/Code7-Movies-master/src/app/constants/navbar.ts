export const navbarConfig = [
  { name: 'Home', isActiveNow: false, route: '/', icon: 'home' },
  {
    name: 'Search',
    isActiveNow: false,
    route: '/pesquisar',
    icon: 'search',
  },
  { name: 'Favorites', isActiveNow: false, route: '/favoritos', icon: 'star' },
];
