import { NgModule } from '@angular/core';

import { HeaderComponent } from './header.component';

@NgModule({
  imports: [],
  exports: [HeaderComponent],
  declarations: [HeaderComponent],
  providers: [],
})
export class HeaderModule {}
