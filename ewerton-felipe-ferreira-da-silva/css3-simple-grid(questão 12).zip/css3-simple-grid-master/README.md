# CSS3 Simple Grid

Grid layout simples, em CSS3.

### Instalação e execução

Instale as dependências, através do seu Git bash/Powershell/CMD/etc.
```bash
npm install
```
... e inicie a aplicação :)
```bash
npm start
```
