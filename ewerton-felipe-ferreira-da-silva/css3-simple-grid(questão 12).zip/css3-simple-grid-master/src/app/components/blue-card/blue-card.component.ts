import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blue-card',
  templateUrl: './blue-card.component.html',
  styleUrls: ['./blue-card.component.scss']
})
export class BlueCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
